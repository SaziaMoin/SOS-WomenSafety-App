package com.example.sos;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SentMessageActivity extends AppCompatActivity {
    DatabaseHelper databaseHelper;
    TextInputEditText etMessage;
    AppCompatButton btnSave;
    AppCompatButton btnSend;
    String editMsg;

    private static final int SMS_PERMISSION_CODE = 100;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sent_message);

        databaseHelper = new DatabaseHelper(this);

        etMessage = findViewById(R.id.etMessage);
        btnSave = findViewById(R.id.btnSave);
        btnSend = findViewById(R.id.btnSend);

        SharedPreferences sp = getSharedPreferences("message", MODE_PRIVATE);
        editMsg = sp.getString("msg", null);

        if (editMsg != null) {
            showMessage();
        }

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etMessage.getText().toString().isEmpty()) {
                    etMessage.setError("Please enter your message");
                } else {
                    String msg = etMessage.getText().toString();
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putString("msg", msg);
                    editor.apply();
                    Toast.makeText(SentMessageActivity.this, "Message saved successfully", Toast.LENGTH_SHORT).show();
                    showMessage();
                }
            }
        });

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkSmsPermission()) {
                    sendSmsToContacts();
                } else {
                    requestSmsPermission();
                }
            }
        });
    }

    private void showMessage() {
        SharedPreferences sp = getSharedPreferences("message", MODE_PRIVATE);
        String msg = sp.getString("msg", null);
        etMessage.setText(msg);
    }

    private boolean checkSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    private void sendSmsToContacts() {
        SharedPreferences sp = getSharedPreferences("message", MODE_PRIVATE);
        String message = sp.getString("msg", "I am in danger. Please help!");

        // Example contact list
        List<String> contactList = databaseHelper.getAllContacts();
//        ArrayList<String> contactList = new ArrayList<>(Arrays.asList(
//                "7250761207",
//                "9571206604" // Replace with real phone numbers
//        ));

        SmsManager smsManager = SmsManager.getDefault();
        for (String contact : contactList) {
            try {
                smsManager.sendTextMessage(contact, null, message, null, null);
                Toast.makeText(this, "Message sent to " + contact, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Failed to send message to " + contact, Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendSmsToContacts();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
