package com.example.sos;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class SigninActivity extends AppCompatActivity {

    private TextInputEditText nameEditText, phoneEditText, passwordEditText;
    private Button signinButton;
    private DbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        nameEditText = findViewById(R.id.loginName);
        phoneEditText = findViewById(R.id.loginNumber);
        passwordEditText = findViewById(R.id.password);
        signinButton = findViewById(R.id.btnAddContact);

        dbHelper = new DbHelper(this);

        signinButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEditText.getText().toString().trim();
                String phone = phoneEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                if (TextUtils.isEmpty(name) || TextUtils.isEmpty(phone) || TextUtils.isEmpty(password)) {
                    Toast.makeText(SigninActivity.this, "All fields are required", Toast.LENGTH_SHORT).show();
                } else {
                    if (dbHelper.checkUser(phone, password)) {
                        // Existing user, proceed to HomeActivity
                        Intent intent = new Intent(SigninActivity.this, HomeActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        // Attempt to insert new user
                        boolean isInserted = dbHelper.insertUser(name, phone, password);
                        if (isInserted) {
                            Toast.makeText(SigninActivity.this, "Sign In successful. Welcome!", Toast.LENGTH_SHORT).show();

                            // Delay using Handler
                            new android.os.Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    Intent intent = new Intent(SigninActivity.this, HomeActivity.class);
                                    startActivity(intent);
                                    finish();
                                }
                            }, 2000); // 2000 milliseconds = 2 seconds
                        }else {
                            Toast.makeText(SigninActivity.this, "Sign In failed. Please try again.", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
    }
}
