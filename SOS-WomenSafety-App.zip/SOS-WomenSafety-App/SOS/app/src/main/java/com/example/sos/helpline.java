package com.example.sos;

import android.app.Activity;

public class helpline extends Activity {

}
