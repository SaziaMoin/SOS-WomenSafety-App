package com.example.sos;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ContactRecyclerAdapter extends RecyclerView.Adapter<ContactRecyclerAdapter.ViewHolder> {

    Context context;
    ArrayList<ContactModel> modelArrayList;
    DatabaseHelper databaseHelper;

    public ContactRecyclerAdapter(Context context, ArrayList<ContactModel> modelArrayList) {
        this.context = context;
        this.modelArrayList = modelArrayList;
    }

    @NonNull
    @Override
    public ContactRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.contact_recycler_view, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactRecyclerAdapter.ViewHolder holder, int position) {
        // Get the current contact model for the position
        ContactModel model = modelArrayList.get(position);

        String id = model.getId();
        holder.name.setText(model.getName());
        holder.number.setText(model.getNumber());

        // Set OnLongClickListener for deleting a contact
        holder.itemView.setOnLongClickListener(view -> {
            new AlertDialog.Builder(context)
                    .setTitle("Delete")
                    .setMessage("Are you sure you want to delete this contact?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        databaseHelper = new DatabaseHelper(context);
                        boolean checkData = databaseHelper.deleteData(id);
                        if (checkData) {
                            Toast.makeText(context, "Contact Deleted", Toast.LENGTH_SHORT).show();
                            modelArrayList.remove(position);
                            notifyItemRemoved(position);
                            notifyItemRangeChanged(position, modelArrayList.size());
                        } else {
                            Toast.makeText(context, "Failed to Delete Contact", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                    .show();

            return true;
        });

        // Set OnClickListener for the Call button
        holder.callButton.setOnClickListener(view -> {
            String phoneNumber = model.getNumber();
            if (phoneNumber != null && !phoneNumber.isEmpty()) {
                Intent callIntent = new Intent(Intent.ACTION_DIAL);
                callIntent.setData(Uri.parse("tel:" + phoneNumber));
                context.startActivity(callIntent);
            } else {
                Toast.makeText(context, "Invalid Phone Number", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return modelArrayList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView name, number;
        Button callButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.recyclerContactName);
            number = itemView.findViewById(R.id.recyclerContactNumber);
            callButton = itemView.findViewById(R.id.call1);
        }
    }
}
