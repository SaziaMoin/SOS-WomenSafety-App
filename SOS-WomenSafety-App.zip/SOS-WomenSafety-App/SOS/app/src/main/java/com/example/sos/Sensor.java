package com.example.sos;
import android.content.Context;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import androidx.appcompat.app.AppCompatActivity;

public class Sensor extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private android.hardware.Sensor accelerometer;
    private boolean isRunning = false;
    private double accelerationThreshold = 15.0; // Adjust as needed
    private LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize SensorManager and Sensor
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(android.hardware.Sensor.TYPE_ACCELEROMETER);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == android.hardware.Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            // Calculate acceleration magnitude
            double acceleration = Math.sqrt(x * x + y * y + z * z);

            if (acceleration > accelerationThreshold && !isRunning) {
                isRunning = true;
                shareLocation();
            }
        }
    }

    @Override
    public void onAccuracyChanged(android.hardware.Sensor sensor, int accuracy) {
        // Not needed for this use case
    }

    private void shareLocation() {
        try {
            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (location != null) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();
                String message = "Emergency! I need help. My location is: https://www.google.com/maps?q=" + latitude + "," + longitude;

                // Send the message to the contact list
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("7250761207", null, message, null, null); // Replace with actual contact
            }
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }
}

