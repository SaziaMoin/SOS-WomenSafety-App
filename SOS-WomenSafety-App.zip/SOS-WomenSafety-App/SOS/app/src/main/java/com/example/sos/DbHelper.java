package com.example.sos;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "user_db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "users";
    public static final String ID = "id";
    public static final String NAME_COLUMN = "name";
    public static final String MOBILE_COLUMN = "phone";
    public static final String PASSWORD_COLUMN = "password";

    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " (" +
                ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NAME_COLUMN + " TEXT, " +
                MOBILE_COLUMN + " TEXT, " +
                PASSWORD_COLUMN + " TEXT)";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean insertUser(String name, String phone, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NAME_COLUMN, name);
        values.put(MOBILE_COLUMN, phone);
        values.put(PASSWORD_COLUMN, password);
        long result = db.insert(TABLE_NAME, null, values);
        return result != -1;
    }
    public int count(){
        int count=0;
        String query="SELECT COUNT(*) FROM "+TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c=db.rawQuery(query,null);
        if(c.getCount()>0){
            c.moveToFirst();
            count=c.getInt(0);
        }
        c.close();
        return count;
    }

    public ArrayList<ContactModel> fetchData(){

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor result = db.rawQuery(" select * from "+TABLE_NAME,null);
        ArrayList<ContactModel> dataArrayList = new ArrayList<>();
        while (result.moveToNext()){
            ContactModel model = new ContactModel();
            model.id = result.getString(0);
            model.name = result.getString(1);
            model.number = result.getString(2);
            model.password = result.getString(3);
            dataArrayList.add(model);
        }
        return dataArrayList;
    }

    public boolean updateData(String id, String name, String mob)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(ID,id);
        contentValues.put(NAME_COLUMN, name);
        contentValues.put(MOBILE_COLUMN, mob);

        int result = db.update(TABLE_NAME, contentValues, "ID = ?",new String[]{id});
        if (result==-1)
            return false;
        else
            return true;
    }

    public boolean checkUser(String phone, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + MOBILE_COLUMN + "=? AND " + PASSWORD_COLUMN + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{phone, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }
}
