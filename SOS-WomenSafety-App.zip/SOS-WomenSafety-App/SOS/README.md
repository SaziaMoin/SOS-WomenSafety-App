# Project Name: Women Safety Application <br>
## Project Overview
The Women Safety App is a user-friendly tool designed to enhance women's safety through modern technology. It enables quick access to help during emergencies with features like an SOS button, live location sharing, and emergency call integration.
The app aims to provide security and confidence by leveraging GPS tracking, geofencing alerts, and offline functionality. Its mission is to create a safer environment for women by offering a reliable, efficient, and accessible safety solution.
## Configuration Instructions
To achieve optimum performance, we recommend the following computer and software configurations:
- Operating System: Android 7.0 (Nougat) or higher
- Minimum RAM: 1GB
- Hardware : Accelerometer and Telephony required
- Storage: 100MB free space

## Installation Instructions
To install the Women Safety Android Application, follow these steps:
1. Download the APK file from the assets section of the release information.
2. Enable installation from unknown sources in your device settings.
3. Open the APK file and follow the on-screen instructions to install the app.
4. Alternatively, clone the repository and import the project into Android Studio.
5. Configure the project settings as needed.
6. Build and run the project on your device or emulator.

## Operating Instructions
The SOS App allows users to:
- Open App
- Register atleast one emergency contact 
- Click on Emergency Mode button
- Click start button
- Allow location permission
- Your emergency mode is acivate now shake you phone

## List of Files Included
- /app: Contains the source code of the Android application.
  - /src: Contains the Java source code files.
  - /res: Contains resources such as layout files, images, and strings.
- /docs: Contains documentation files for the project.
- /README.md: The README file you are currently reading.

## Contact Information
For any inquiries or support, please feel free to contact us:
- Developer:Sazia Moin
- Email : [saziamoin14@gmail.com]

Your support and contributions are greatly appreciated!



